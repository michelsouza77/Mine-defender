import React from "react";
import { Transition } from "@headlessui/react";
import { InnerPanel, OuterPanel } from "components/ui/Panel";
import { useAppTranslation } from "lib/i18n/useAppTranslations";
import { ITEM_DETAILS } from "features/game/types/images";
import coinsIcon from "assets/icons/coins.webp";
import recipeIcon from "assets/decorations/page.png";
import { SUNNYSIDE } from "assets/sunnyside";
import { BumpkinGift } from "features/game/types/gifts";
import { getWearableImage } from "features/game/lib/getWearableImage";
import { getObjectEntries } from "lib/object";

interface Props {
  show: boolean;
  className?: string;
  nextGift: BumpkinGift;
  giftProgress?: string;
  giftTitle?: string;
  onClick: () => void;
}

export const FriendshipInfoPanel: React.FC<Props> = ({
  show,
  className,
  nextGift,
  giftProgress,
  giftTitle,
  onClick,
}) => {
  const { t } = useAppTranslation();

  return (
    <Transition
      appear={true}
      id="friendship-gifts-info-panel"
      show={show}
      enter="transition-opacity transition-transform duration-200"
      enterFrom="opacity-0"
      enterTo="opacity-100"
      leave="transition-opacity duration-100"
      leaveFrom="opacity-100"
      leaveTo="opacity-0"
      className={`flex absolute z-40 ${className}`}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      as="div"
    >
      <OuterPanel className="drop-shadow-lg cursor-pointer max-w-md">
        <InnerPanel className="flex flex-col -m-0.5">
          <div className="flex space-x-1 mb-1.5">
            <span className="text-xs whitespace-nowrap">{giftTitle}</span>
          </div>
          <div className="space-y-1">
            {!!nextGift.wearables &&
              getObjectEntries(nextGift.wearables).map(([wearable, count]) => {
                const image = getWearableImage(wearable);

                return (
                  <div
                    key={wearable}
                    className="capitalize space-x-1 flex items-center"
                  >
                    {!!wearable && (
                      <>
                        <img
                          src={image}
                          alt={wearable}
                          className="w-4 mr-0.5"
                        />
                        <span className="text-xs">{`${count} ${wearable}`}</span>
                      </>
                    )}
                  </div>
                );
              })}

            {!!nextGift.items &&
              getObjectEntries(nextGift.items).map(([item, count]) => (
                <div
                  key={item}
                  className="capitalize space-x-1 flex items-center"
                >
                  {item && (
                    <>
                      <img
                        src={
                          ITEM_DETAILS[item]?.image ??
                          SUNNYSIDE.icons.expression_confused
                        }
                        alt={item}
                        className="w-4 mr-0.5"
                      />
                      <span className="text-xs">{`${count} ${item}`}</span>
                    </>
                  )}
                </div>
              ))}

            {!!nextGift.coins && (
              <div className="capitalize space-x-1 flex items-center">
                <img src={coinsIcon} alt="Coins" className="w-4 mr-0.5" />
                <span className="text-xs">{`${nextGift.coins} ${t("coins")}`}</span>
              </div>
            )}

            {!!nextGift.recipe && (
              <div className="capitalize space-x-1 flex items-center">
                <img src={recipeIcon} alt="Coins" className="w-4 mr-0.5" />
                <span className="text-xs">{t("recipe")}</span>
              </div>
            )}
          </div>
        </InnerPanel>
        {!!giftProgress && (
          <InnerPanel className="flex flex-col -m-0.5 mt-1">
            <div className="flex mb-1.5">
              <span className="text-xs whitespace-nowrap">
                {t("friendship.gift.progress")}
              </span>
            </div>
            <div className="capitalize space-x-1 flex items-center">
              <img
                src={SUNNYSIDE.icons.heart}
                alt="Heart"
                className="w-4 mr-0.5"
              />
              <span className="text-xs">{giftProgress}</span>
            </div>
          </InnerPanel>
        )}
      </OuterPanel>
    </Transition>
  );
};
